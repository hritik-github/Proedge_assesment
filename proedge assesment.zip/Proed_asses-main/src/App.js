
import './App.css';
var text="";
function formsubmit()
{
  alert("form submitted");
  console.log(text);
}
function change(value)
{
   text=value;  
}
function App() {
  return (
    <div className="App">
      <form onsubmit={(e)=> formsubmit()}>
        Roll Nos:<input  type="text"  onChange={(e)=>change(e.target.value)}/><br/>
        <input type="submit" value="submit" />
      </form>
    </div>
  );
}

export default App;
